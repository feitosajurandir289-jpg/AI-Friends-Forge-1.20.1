# AI Friends — Forge 1.20.1 (protótipo 0.1.1)

Projeto-fonte de um mod de companheiros para Minecraft Java 1.20.1 / Forge 47.2.0 / Java 17.

## Implementado nesta etapa
- Entidade humanoide com modelo de jogador e textura Steve.
- Ovo de invocação na aba de ovos de criaturas.
- Ao interagir pela primeira vez, o jogador reivindica o companheiro.
- O companheiro recebe um nome e uma personalidade de um conjunto inicial de cinco perfis.
- Interagir novamente alterna entre **seguir** e **esperar no lugar**.
- O companheiro olha para o dono e acompanha quando está no modo seguir.
- O companheiro reage a monstros próximos.
- Dono, personalidade e modo de comportamento são salvos no mundo.

## Como testar
1. Compile o projeto em um ambiente com Java 17 e Gradle.
2. Inicie Minecraft 1.20.1 com Forge.
3. Pegue o ovo `AI Player Spawn Egg` na aba de ovos de criaturas (modo criativo).
4. Invoque até cinco companheiros.
5. Clique com o botão direito em cada um para reivindicá-lo.
6. Clique novamente para alternar entre seguir e esperar.

## Ainda não implementado
Esta versão ainda não possui conversa livre com IA, inventário funcional, coleta, mineração, crafting, evolução de ferramentas ou integração direta com o Warehouse do MineColonies. Esses sistemas serão adicionados em etapas separadas e precisam ser testados com as versões exatas dos mods instalados.

## Compilação
É necessário Java 17 e Gradle, além de internet para baixar as dependências do ForgeGradle.

Na pasta do projeto, execute:

```bash
gradle build
```

O JAR será gerado em `build/libs/`.

## Compatibilidade declarada
- Minecraft Java 1.20.1
- Minecraft Forge 47.2.0
- Java 17

**Aviso:** este pacote contém código-fonte, não um JAR compilado. O ambiente disponível nesta etapa não possui Gradle, portanto a compilação e o teste dentro do Minecraft ainda não foram realizados.
