package br.com.aifriends.registry;

import br.com.aifriends.AIPlayersMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AIPlayersMod.MOD_ID);

    public static final RegistryObject<Item> AI_PLAYER_SPAWN_EGG =
            ITEMS.register("ai_player_spawn_egg", () ->
                    new ForgeSpawnEggItem(ModEntities.AI_PLAYER, 0x3B6EA8, 0xE7C99A, new Item.Properties()));
}
