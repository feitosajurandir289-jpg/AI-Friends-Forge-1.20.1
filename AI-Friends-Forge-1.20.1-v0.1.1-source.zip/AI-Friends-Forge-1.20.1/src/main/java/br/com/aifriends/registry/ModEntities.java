package br.com.aifriends.registry;

import br.com.aifriends.AIPlayersMod;
import br.com.aifriends.entity.AIPlayerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AIPlayersMod.MOD_ID);

    public static final RegistryObject<EntityType<AIPlayerEntity>> AI_PLAYER =
            ENTITIES.register("ai_player", () -> EntityType.Builder
                    .of(AIPlayerEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F)
                    .build("ai_player"));
}
