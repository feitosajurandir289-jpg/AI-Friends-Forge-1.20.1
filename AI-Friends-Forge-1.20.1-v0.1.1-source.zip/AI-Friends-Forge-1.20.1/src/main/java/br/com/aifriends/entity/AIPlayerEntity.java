package br.com.aifriends.entity;

import java.util.EnumSet;
import java.util.UUID;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class AIPlayerEntity extends PathfinderMob {
    private static final String[] COMPANION_NAMES = {"Ravi", "Luna", "Theo", "Nina", "Kai"};
    private static final String[] PERSONALITIES = {
            "Explorador", "Estrategista", "Construtor", "Aventureiro", "Observador"
    };

    private UUID ownerUUID;
    private String personality = "Explorador";
    private boolean followingOwner = true;

    public AIPlayerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (this.level().isClientSide) return InteractionResult.SUCCESS;

        if (ownerUUID == null) {
            ownerUUID = player.getUUID();
            int profile = this.getRandom().nextInt(COMPANION_NAMES.length);
            personality = PERSONALITIES[profile];
            this.setCustomName(Component.literal(COMPANION_NAMES[profile]));
            this.setCustomNameVisible(true);
            followingOwner = true;
            player.sendSystemMessage(Component.literal(COMPANION_NAMES[profile]
                    + ": Prazer! Sou seu companheiro. Minha personalidade é " + personality
                    + ". Vou acompanhar você."));
            return InteractionResult.CONSUME;
        }

        if (!ownerUUID.equals(player.getUUID())) {
            player.sendSystemMessage(Component.literal("Este companheiro já pertence a outro jogador."));
            return InteractionResult.CONSUME;
        }

        followingOwner = !followingOwner;
        if (followingOwner) {
            player.sendSystemMessage(Component.literal(this.getName().getString() + ": Certo, vou seguir você!"));
        } else {
            this.getNavigation().stop();
            player.sendSystemMessage(Component.literal(this.getName().getString() + ": Tudo bem, vou esperar aqui."));
        }
        return InteractionResult.CONSUME;
    }

    public String getPersonality() {
        return personality;
    }

    public boolean isFollowingOwner() {
        return followingOwner;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerUUID != null) tag.putUUID("OwnerUUID", ownerUUID);
        tag.putString("Personality", personality);
        tag.putBoolean("FollowingOwner", followingOwner);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("OwnerUUID")) ownerUUID = tag.getUUID("OwnerUUID");
        if (tag.contains("Personality")) personality = tag.getString("Personality");
        if (tag.contains("FollowingOwner")) followingOwner = tag.getBoolean("FollowingOwner");
    }

    private static class FollowOwnerGoal extends Goal {
        private final AIPlayerEntity companion;
        private ServerPlayer owner;

        FollowOwnerGoal(AIPlayerEntity companion) {
            this.companion = companion;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (!companion.followingOwner || companion.ownerUUID == null || companion.level().isClientSide) {
                return false;
            }
            Player player = companion.level().getPlayerByUUID(companion.ownerUUID);
            if (!(player instanceof ServerPlayer serverPlayer) || !serverPlayer.isAlive()) return false;
            owner = serverPlayer;
            return companion.distanceToSqr(owner) > 9.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return companion.followingOwner && owner != null && owner.isAlive()
                    && companion.distanceToSqr(owner) > 4.0D
                    && companion.distanceToSqr(owner) < 1600.0D;
        }

        @Override
        public void tick() {
            if (owner == null) return;
            companion.getLookControl().setLookAt(owner, 10.0F, companion.getMaxHeadXRot());
            if (companion.distanceToSqr(owner) > 144.0D) {
                companion.teleportTo(owner.getX(), owner.getY(), owner.getZ());
            } else {
                companion.getNavigation().moveTo(owner, 1.0D);
            }
        }

        @Override
        public void stop() {
            owner = null;
            companion.getNavigation().stop();
        }
    }
}
